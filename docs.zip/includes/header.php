<?php
/**
 * header.php — Navbar compartida del sistema
 * Requiere que $pageTitle y $activeMenu estén definidos antes de incluir
 * MESORA | Sistema SaaS para restaurantes
 */

if (!defined('BASE_URL') || empty($_SESSION['usuario_id']) || empty($_SESSION['rol'])) return;

// Determinar el rol para badge y colores
$rolLabel = [
    'superadmin' => 'Super Admin',
    'admin'      => 'Administrador',
    'encargado'  => 'Encargado',
    'atencion'   => 'Atención',
    'cocina'     => 'Cocina',
][$_SESSION['rol']] ?? $_SESSION['rol'];

$nombreInicial = strtoupper(substr($_SESSION['nombre'] ?? 'U', 0, 1));

// Prefijo de ruta según rol
$baseRol = BASE_URL . '/roles/' . $_SESSION['rol'];

// ── Branding dinámico por restaurante ──────────────────────────
// Para roles no-superadmin que tienen restaurante_id, cargar su branding
$_brandingLogo   = BASE_URL . '/assets/mesora.webp'; // fallback genérico
$_brandingNombre = 'MESORA';                       // fallback genérico
if (!empty($_SESSION['restaurante_id']) && $_SESSION['rol'] !== 'superadmin') {
    // Usar conexión ya existente si está disponible, si no abrir una nueva
    try {
        $_dbB = getDB();
        $_stB = $_dbB->prepare("
            SELECT fc.logo, fc.nombre_comercial, r.nombre
            FROM restaurantes r
            LEFT JOIN facturacion_config fc ON fc.restaurante_id = r.id
            WHERE r.id = ?
        ");
        $_stB->execute([$_SESSION['restaurante_id']]);
        $_brand = $_stB->fetch();
        if ($_brand) {
            // Logo: usar el de facturacion_config si existe y el archivo está en disco
            $__logo = $_brand['logo'] ?? null;
            if ($__logo && file_exists($_SERVER['DOCUMENT_ROOT'] . $__logo)) {
                $_brandingLogo = htmlspecialchars($__logo);
            }
            // Nombre: nombre_comercial tiene prioridad sobre nombre del restaurante
            $_brandingNombre = htmlspecialchars(
                !empty($_brand['nombre_comercial']) ? $_brand['nombre_comercial'] : $_brand['nombre']
            );
        }
    } catch (Exception $_eB) { /* silencioso — usa fallback */ }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="theme-color" content="#1A1A2E">
    <meta name="description" content="MESORA — Sistema de gestión para restaurantes">
    <title><?= htmlspecialchars($pageTitle ?? 'MESORA') ?> | MESORA</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <script>
        window.BASE_URL = <?= json_encode(BASE_URL, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        window.CSRF_TOKEN = <?= json_encode(getCsrfToken()) ?>;
        (() => {
            const contexto = <?= json_encode(
                $_SESSION['rol'] === 'superadmin' && !empty($_SESSION['_contexto_restaurante'])
                    ? ['id' => (int)$_SESSION['restaurante_id'], 'token' => $_SESSION['_contexto_restaurante']]
                    : null
            ) ?>;
            const app = new URL(window.BASE_URL.replace(/\/$/, '') + '/', window.location.origin);
            const original_fetch = window.fetch.bind(window);
            window.fetch = (input, opciones = {}) => {
                const solicitud = input instanceof Request ? input : null;
                const url = new URL(solicitud ? solicitud.url : input, window.location.href);
                if (app.origin !== window.location.origin || url.origin !== app.origin
                    || !url.pathname.startsWith(app.pathname + 'api/')) {
                    return original_fetch(input, opciones);
                }
                const metodo = (opciones.method || solicitud?.method || 'GET').toUpperCase();
                const cabeceras = new Headers(opciones.headers ?? solicitud?.headers);
                if (metodo === 'POST') cabeceras.set('X-CSRF-Token', window.CSRF_TOKEN);
                if (contexto) {
                    cabeceras.set('X-Restaurante-Esperado', String(contexto.id));
                    cabeceras.set('X-Contexto-Restaurante', contexto.token);
                }
                // Las API no redirigen: los tokens solo deben ir a la ruta validada.
                return original_fetch(input, { ...opciones, headers: cabeceras, redirect: 'error' });
            };
        })();
    </script>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css?v=<?= filemtime(__DIR__ . '/../assets/css/main.css') ?>">
</head>
<body>

<!-- Navbar principal -->
<nav class="navbar">
    <div class="navbar-brand">
        <?php if ($_SESSION['rol'] === 'superadmin'): ?>
            <img src="<?= BASE_URL ?>/assets/mesora.webp" alt="MESORA" style="height:32px;width:auto;">
        <?php else: ?>
            <img src="<?= $_brandingLogo ?>" alt="<?= $_brandingNombre ?>"
                 style="height:36px;width:auto;max-width:120px;object-fit:contain;border-radius:4px;">
            <span style="font-size:.82rem;font-weight:700;color:rgba(255,255,255,.92);margin-left:8px;
                         max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
                         letter-spacing:.01em;">
                <?= $_brandingNombre ?>
            </span>
        <?php endif; ?>
    </div>
    <div class="navbar-right">
        <?php if ($_SESSION['rol'] === 'superadmin' && isset($_SESSION['_nombre_contexto_restaurante'])): ?>
            <span class="badge" title="Restaurante seleccionado">
                <?= htmlspecialchars($_SESSION['_nombre_contexto_restaurante'], ENT_QUOTES, 'UTF-8') ?>
            </span>
        <?php endif; ?>
        <?php if (($_SESSION['rol'] ?? '') === 'superadmin' && strpos($_SERVER['REQUEST_URI'] ?? '', '/roles/admin/') !== false): ?>
            <a href="<?= BASE_URL ?>/roles/superadmin/dashboard.php"
               style="margin-right:8px; color:rgba(255,255,255,.85); font-size:0.8rem; text-decoration:none; background:rgba(255,255,255,.15); padding:6px 12px; border-radius:6px; border:1px solid rgba(255,255,255,.2); display:inline-flex; align-items:center; gap:6px; min-height:44px;">
               <i class="fa-solid fa-arrow-left"></i> Panel global
            </a>
        <?php endif; ?>
    </div>
</nav>

<div class="layout-admin">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <div class="main-content">

<!-- Modal de opciones secuenciales (global, disponible en todas las páginas) -->
<div class="modal-overlay" id="modal-opciones">
    <div class="modal">
        <div class="modal-header">
            <div>
                <div class="modal-title" id="modal-opciones-titulo">Elige una opción</div>
                <div style="font-size:.78rem;color:var(--text-secondary);margin-top:2px" id="modal-opciones-subtitulo"></div>
            </div>
        </div>
        <div class="modal-body">
            <div class="opciones-list" id="modal-opciones-lista"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost btn-full" id="modal-opciones-cancelar">Cancelar</button>
            <button class="btn btn-primario btn-full" id="modal-opciones-confirmar">Continuar <i class="fa-solid fa-arrow-right"></i></button>
        </div>
    </div>
</div>

<!-- Modal de confirmación genérico -->
<div class="modal-overlay" id="modal-confirmar">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title">
                <i class="fa-solid fa-triangle-exclamation" style="color:var(--warning);"></i> Confirmar acción
            </div>
        </div>
        <div class="modal-body">
            <p id="modal-confirmar-msg" style="color:var(--text-primary);font-size:.95rem;"></p>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost btn-full" onclick="Modal.cerrar('modal-confirmar')">Cancelar</button>
            <button class="btn btn-peligro btn-full" id="modal-confirmar-btn">Confirmar</button>
        </div>
    </div>
</div>
