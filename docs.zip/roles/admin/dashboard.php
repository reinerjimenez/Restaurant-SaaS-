<?php
/**
 * roles/admin/dashboard.php — Panel del Administrador
 * MESORA | Sistema SaaS para restaurantes
 */
require_once '../../config/db.php';
requireRole(['admin', 'encargado', 'superadmin']);

require_once __DIR__ . '/../../includes/reportes_financieros.php';

$restauranteId = $_SESSION['restaurante_id'];
$db = getDB();

// ── Métricas del día ─────────────────────────────────────────
$hoy = date('Y-m-d');
$fin_exclusivo = limite_exclusivo_reporte($hoy);
$periodo = ingresos_periodo($db, $restauranteId, $hoy, $fin_exclusivo);
$ventas = ['total_dia' => $periodo['total_centimos'] / 100, 'pedidos_dia' => $periodo['pedidos']];
$gastosDia = gastos_contables_periodo($db, $restauranteId, $hoy, $fin_exclusivo);
$utilidadDia = ($periodo['total_centimos'] - centimos_reporte($gastosDia)) / 100;

$stMesas = $db->prepare("SELECT COUNT(*) AS ocupadas FROM mesas m WHERE m.restaurante_id = ? AND m.activo = 1 AND (m.estado = 'ocupada' OR EXISTS (SELECT 1 FROM pedidos p WHERE p.mesa_id = m.id AND p.estado = 'activo'))");
$stMesas->execute([$restauranteId]);
$mesasOcupadas = $stMesas->fetchColumn();

$stTotal = $db->prepare("SELECT COUNT(*) FROM mesas WHERE restaurante_id = ? AND activo = 1");
$stTotal->execute([$restauranteId]);
$totalMesas = $stTotal->fetchColumn();

$stActivos = $db->prepare("SELECT COUNT(*) FROM pedidos WHERE restaurante_id = ? AND estado = 'activo'");
$stActivos->execute([$restauranteId]);
$pedidosActivos = $stActivos->fetchColumn();

$metodoMap = array_column($periodo['metodos'], 'total', 'metodo');
$topProductos = productos_periodo($db, $restauranteId, $hoy, $fin_exclusivo, 5);
$ultimosPedidos = cobros_periodo($db, $restauranteId, $hoy, $fin_exclusivo, '', 0, 8);

$stRest = $db->prepare("
    SELECT r.nombre,
           fc.logo, fc.nombre_comercial, fc.ruc, fc.direccion_fiscal, fc.telefono
    FROM restaurantes r
    LEFT JOIN facturacion_config fc ON fc.restaurante_id = r.id
    WHERE r.id = ?
");
$stRest->execute([$restauranteId]);
$restaurante = $stRest->fetch();

// Nombre a mostrar: nombre_comercial > nombre del restaurante
$nombreMostrar = !empty($restaurante['nombre_comercial'])
    ? $restaurante['nombre_comercial']
    : ($restaurante['nombre'] ?? 'Restaurante');

$pageTitle = 'Dashboard';
$activeMenu = 'dashboard';
require_once '../../includes/header.php';
?>

<style>
/* Estilos responsive para el Dashboard */
.head-dashboard {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 24px;
}
.head-brand {
    display: flex;
    align-items: center;
    gap: 16px;
}
.head-brand-info h1 {
    font-size: 1.6rem;
    margin-bottom: 6px;
    line-height: 1.2;
}
.head-brand-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 6px 12px;
    color: var(--text-secondary);
    font-size: 0.85rem;
    align-items: center;
}
.head-brand-meta span {
    display: flex;
    align-items: center;
}
.head-actions {
    display: flex;
    gap: 8px;
}
.dashboard-bottom-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin-bottom: 24px;
}

@media (max-width: 768px) {
    .head-dashboard {
        flex-direction: column;
        align-items: flex-start;
        gap: 16px;
    }
    .head-brand {
        width: 100%;
    }
    .head-brand-info h1 {
        font-size: 1.35rem;
    }
    .head-actions {
        width: 100%;
    }
    .head-actions .btn {
        flex: 1;
        justify-content: center;
    }
    .dashboard-bottom-grid {
        grid-template-columns: 1fr;
    }
}
</style>

        <div class="page-content">

            <!-- Encabezado con Branding -->
            <div class="head-dashboard">
                <div class="head-brand">
                    <?php
                    $logoPath = $restaurante['logo'] ?? null;
                    $logoSrc  = ($logoPath && file_exists($_SERVER['DOCUMENT_ROOT'] . $logoPath))
                        ? htmlspecialchars($logoPath)
                        : BASE_URL . '/assets/mesora.webp';
                    ?>
                    <div style="width:64px;height:64px;border-radius:var(--radius-md);overflow:hidden;
                                border:2px solid var(--border);background:var(--bg-secondary);
                                display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                        <img src="<?= $logoSrc ?>" alt="Logo" style="max-width:100%;max-height:100%;object-fit:contain;">
                    </div>
                    <div class="head-brand-info">
                        <h1><?= htmlspecialchars($nombreMostrar) ?></h1>
                        <div class="head-brand-meta">
                            <?php if (!empty($restaurante['ruc'])): ?>
                                <span><i class="fa-solid fa-id-card" style="margin-right:5px;font-size:0.75rem;"></i> RUC <?= htmlspecialchars($restaurante['ruc']) ?></span>
                            <?php endif; ?>
                            <span><i class="fa-regular fa-calendar" style="margin-right:5px;"></i> <?= date('d/m/Y') ?></span>
                            <?php if (!empty($restaurante['telefono'])): ?>
                                <span><i class="fa-solid fa-phone" style="margin-right:5px;font-size:0.75rem;"></i> <?= htmlspecialchars($restaurante['telefono']) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="head-actions">
                    <a href="config_facturacion.php" class="btn btn-ghost btn-sm">
                        <i class="fa-solid fa-store"></i> Mi Restaurante
                    </a>
                    <a href="reportes.php" class="btn btn-ghost btn-sm">
                        <i class="fa-solid fa-chart-line"></i> Ver reportes
                    </a>
                </div>
            </div>

            <!-- Estadísticas -->
            <div class="stats-grid mb-24">
                <div class="stat-card verde">
                    <div class="stat-icon"><i class="fa-solid fa-sack-dollar"></i></div>
                    <div class="stat-valor">S/ <?= number_format($ventas['total_dia'], 2) ?></div>
                    <div class="stat-label">Ingresos hoy</div>
                </div>
                <div class="stat-card rojo">
                    <div class="stat-icon"><i class="fa-solid fa-money-bill-transfer"></i></div>
                    <div class="stat-valor">S/ <?= number_format($gastosDia, 2) ?></div>
                    <div class="stat-label">Gastos hoy</div>
                </div>
                <div class="stat-card azul" style="background: var(--primary-light); border-color: var(--primary);">
                    <div class="stat-icon" style="color: var(--primary);"><i class="fa-solid fa-piggy-bank"></i></div>
                    <div class="stat-valor" style="color: var(--primary);">S/ <?= number_format($utilidadDia, 2) ?></div>
                    <div class="stat-label" style="color: var(--primary);">Utilidad hoy</div>
                </div>
                <div class="stat-card naranja">
                    <div class="stat-icon"><i class="fa-solid fa-chair"></i></div>
                    <div class="stat-valor"><?= $mesasOcupadas ?> / <?= $totalMesas ?></div>
                    <div class="stat-label">Mesas ocupadas</div>
                </div>
            </div>

            <div class="stats-grid mb-24">
                <div class="stat-card rojo">
                    <div class="stat-icon"><i class="fa-solid fa-receipt"></i></div>
                    <div class="stat-valor"><?= $ventas['pedidos_dia'] ?></div>
                    <div class="stat-label">Pedidos cobrados</div>
                </div>
                <div class="stat-card dorado">
                    <div class="stat-icon"><i class="fa-solid fa-hourglass-half"></i></div>
                    <div class="stat-valor"><?= $pedidosActivos ?></div>
                    <div class="stat-label">Pedidos activos</div>
                </div>
            </div>

            <!-- Ingresos por método de pago -->
            <div class="card mb-24">
                <div class="card-title"><i class="fa-solid fa-credit-card"></i> Ingresos por método de pago — hoy</div>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px;">
                    <?php
                    $metodoInfo = [
                        'efectivo'      => ['fa-money-bill-wave', 'Efectivo'],
                        'yape'          => ['fa-mobile-screen',   'Yape'],
                        'transferencia' => ['fa-building-columns','Transferencia'],
                        'tarjeta'       => ['fa-credit-card',     'Tarjeta'],
                        'otro'          => ['fa-rotate',          'Otro'],
                    ];
                    foreach ($metodoInfo as $key => [$icon, $label]): ?>
                    <div style="background:var(--bg-secondary);border-radius:var(--radius-md);padding:14px 12px;text-align:center;border:1px solid var(--border);">
                        <div style="font-size:1.4rem;color:var(--primary);margin-bottom:6px;"><i class="fa-solid <?= $icon ?>"></i></div>
                        <div style="font-weight:800;font-size:1rem;margin:4px 0;color:var(--text-primary);">S/ <?= number_format($metodoMap[$key] ?? 0, 2) ?></div>
                        <div style="font-size:.72rem;color:var(--text-secondary);font-weight:500;"><?= $label ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="dashboard-bottom-grid">
                <!-- Top productos -->
                <div class="card">
                    <div class="card-title"><i class="fa-solid fa-trophy"></i> Top productos hoy</div>
                    <?php if ($topProductos): ?>
                    <div style="display:flex;flex-direction:column;gap:10px;">
                        <?php foreach ($topProductos as $i => $p): ?>
                        <div style="display:flex;align-items:center;gap:10px;">
                            <div style="width:26px;height:26px;background:<?= $i===0?'var(--warning)':($i===1?'var(--border)':'var(--bg-secondary)') ?>;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;color:var(--text-primary);flex-shrink:0;"><?= $i+1 ?></div>
                            <div style="flex:1;">
                                <div style="font-size:.875rem;font-weight:600;color:var(--text-primary);"><?= htmlspecialchars($p['nombre']) ?></div>
                                <div style="font-size:.72rem;color:var(--text-secondary);"><?= $p['vendidos'] ?> vendidos</div>
                            </div>
                            <div style="font-size:.875rem;font-weight:700;color:var(--primary);">S/ <?= number_format($p['ingreso'],2) ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div class="empty-state" style="padding:30px 0;">
                        <div class="icon"><i class="fa-solid fa-utensils"></i></div>
                        <p>Sin ventas hoy aún</p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Últimos pedidos -->
                <div class="card">
                    <div class="card-title"><i class="fa-solid fa-clock-rotate-left"></i> Últimos pedidos</div>
                    <?php if ($ultimosPedidos): ?>
                    <div style="display:flex;flex-direction:column;gap:8px;">
                        <?php foreach ($ultimosPedidos as $p): ?>
                        <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);">
                            <span style="color:var(--text-muted);font-size:.875rem;">
                                <i class="fa-solid <?= $p['tipo']==='aqui' ? 'fa-house' : 'fa-bag-shopping' ?>"></i>
                            </span>
                            <div style="flex:1;">
                                <div style="font-size:.82rem;font-weight:600;color:var(--text-primary);">
                                    <?= $p['mesa_numero'] ? 'Mesa '.$p['mesa_numero'] : 'Para Llevar' ?>
                                </div>
                                <div style="font-size:.7rem;color:var(--text-secondary);"><?= htmlspecialchars($p['cajero']) ?> · <?= date('H:i', strtotime($p['cobrado_en'])) ?></div>
                            </div>
                            <div style="font-weight:700;font-size:.88rem;color:var(--success);">S/ <?= number_format($p['total'],2) ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div class="empty-state" style="padding:30px 0;">
                        <div class="icon"><i class="fa-solid fa-receipt"></i></div>
                        <p>Sin pedidos cobrados hoy</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

<?php require_once '../../includes/footer.php'; ?>
